package shapelauncher;

public class AnglePanel {
	public double angle;
}
